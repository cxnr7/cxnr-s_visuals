# cxnr's-visuals

Client-side Fabric mod for **Minecraft 1.21.11**.

* **Atmosphere** - presets (Fireflies, Flowers, Soft Snow, Snowstorm, Embers, Ashfall, Spores, Stardust, Mist) with
  intensity, speed, particle size, wind, ground / mid / sky layers, radius, particle cap and custom tint.
* **Crosshair** - 6 shapes, outline, color modes, dynamic spread, cooldown bar, live preview.
* **Hit effects** - hit marker, damage popup, particles, sound.
* **Kill effects** - kill marker, "Eliminated ..." message, screen flash, particle burst, sound.
* **Menu** - glass-style GUI on **Right Shift** (rebindable in the Interface tab).

Settings are saved to `config/cxnrs-visuals.json`.

## Getting the .jar

The finished file is `build/libs/cxnr's-visuals.jar`.

### Option A - let GitHub build it (no installs)
1. Make a free GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the **Actions** tab, wait for the `build` run to go green, open it and download the **cxnrs-visuals-jar** artifact.
3. Unzip it. Inside is `cxnr's-visuals.jar`.

### Option B - build it yourself
1. Install **JDK 21** (e.g. Eclipse Temurin) and **Gradle** (latest).
2. In this folder run: `gradle build`
3. Take `build/libs/cxnr's-visuals.jar`.

If Gradle complains that a version can't be found, open https://fabricmc.net/develop , pick 1.21.11 and copy the
`yarn_mappings`, `loader_version`, `loom_version` and `fabric_version` lines into `gradle.properties`.

## Installing
1. Install Fabric Loader (0.18.1 or newer) for 1.21.11 and put **Fabric API** in your `mods` folder.
2. Put `cxnr's-visuals.jar` in the same `mods` folder.
3. Join a world and press **Right Shift**.

## Notes
* The vanilla crosshair is hidden through a tiny mixin (`InGameHudMixin`). If Mojang renames that method the mod still
  loads, you would just see both crosshairs.
* Everything here is visual and client-side only. Check a server's rules before using it on multiplayer.
