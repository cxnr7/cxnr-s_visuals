package dev.cxnr.visuals;

import dev.cxnr.visuals.atmosphere.AtmosphereManager;
import dev.cxnr.visuals.combat.CombatTracker;
import dev.cxnr.visuals.combat.Effects;
import dev.cxnr.visuals.config.VisualsConfig;
import dev.cxnr.visuals.crosshair.CrosshairRenderer;
import dev.cxnr.visuals.gui.VisualsScreen;
import dev.cxnr.visuals.util.Keys;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;

public final class CxnrVisuals implements ClientModInitializer {
    public static final String MOD_ID = "cxnrs_visuals";
    public static final String VERSION = "1.0.0";

    /** Shared between the tick handler and the menu so one key press never opens and closes in the same breath. */
    public static boolean openKeyWasDown = true;

    private static boolean screenWasOpen;
    private static boolean warned;
    private static boolean wasInWorld;

    @Override
    public void onInitializeClient() {
        VisualsConfig.load();

        ClientTickEvents.END_CLIENT_TICK.register(CxnrVisuals::onTick);

        HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT, Identifier.of(MOD_ID, "overlay"),
                (context, tickCounter) -> {
                    try {
                        CrosshairRenderer.renderHud(context);
                        Effects.renderHud(context);
                    } catch (RuntimeException e) {
                        warn(e);
                    }
                });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (world instanceof ClientWorld) {
                try {
                    CombatTracker.onAttack(entity);
                } catch (RuntimeException e) {
                    warn(e);
                }
            }
            return ActionResult.PASS;
        });
    }

    private static void onTick(MinecraftClient client) {
        try {
            boolean open = client.currentScreen instanceof VisualsScreen;
            if (screenWasOpen && !open) VisualsConfig.save();
            screenWasOpen = open;

            boolean down = Keys.isDown(client.getWindow().getHandle(), VisualsConfig.get().openKey);
            if (down && !openKeyWasDown && client.currentScreen == null && client.world != null && client.player != null) {
                client.setScreen(new VisualsScreen());
            }
            openKeyWasDown = down;

            boolean inWorld = client.world != null && client.player != null;
            if (!inWorld) {
                if (wasInWorld) {
                    AtmosphereManager.reset();
                    CombatTracker.reset();
                    Effects.reset();
                }
                wasInWorld = false;
                return;
            }
            wasInWorld = true;
            if (client.isPaused()) return;
            AtmosphereManager.tick(client);
            CombatTracker.tick(client);
        } catch (RuntimeException e) {
            warn(e);
        }
    }

    private static void warn(RuntimeException e) {
        if (warned) return;
        warned = true;
        System.err.println("[cxnr's-visuals] Something went wrong (only shown once): " + e);
        e.printStackTrace();
    }
}
