package dev.cxnr.visuals.atmosphere;

import dev.cxnr.visuals.config.VisualsConfig;
import dev.cxnr.visuals.gui.Gfx;
import dev.cxnr.visuals.util.Particles;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.BillboardParticle;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/** Spawns and steers the ambient particles around the player. */
public final class AtmosphereManager {
    private static final int NONE = Integer.MIN_VALUE;
    private static final Random RNG = new Random();
    private static final ArrayList<Tracked> TRACKED = new ArrayList<>();
    private static final HashMap<Long, Integer> GROUND_CACHE = new HashMap<>();
    private static final HashMap<Long, Integer> TOP_CACHE = new HashMap<>();
    private static final BlockPos.Mutable MUT = new BlockPos.Mutable();

    private static Preset lastPreset;
    private static int ticks;
    private static int cacheY = Integer.MIN_VALUE;

    private AtmosphereManager() {}

    private static final class Tracked {
        final Particle particle;
        final float vx, vy, vz, sway, phase, windScale;
        final boolean driven;
        int age;

        Tracked(Particle particle, float vx, float vy, float vz, float sway, float windScale, boolean driven) {
            this.particle = particle;
            this.vx = vx;
            this.vy = vy;
            this.vz = vz;
            this.sway = sway;
            this.windScale = windScale;
            this.driven = driven;
            this.phase = RNG.nextFloat() * 6.2831f;
        }
    }

    /** Removes every particle this mod spawned (used when switching presets or turning the module off). */
    public static void clear() {
        for (Tracked t : TRACKED) t.particle.markDead();
        TRACKED.clear();
    }

    /** Forget everything without touching particles (world change). */
    public static void reset() {
        TRACKED.clear();
        GROUND_CACHE.clear();
        TOP_CACHE.clear();
        lastPreset = null;
    }

    public static void tick(MinecraftClient mc) {
        VisualsConfig.Atmosphere cfg = VisualsConfig.get().atmosphere;
        ClientWorld world = mc.world;
        if (world == null || mc.player == null) return;
        ticks++;

        if (!cfg.enabled) {
            if (!TRACKED.isEmpty()) clear();
            lastPreset = null;
            return;
        }
        if (lastPreset != cfg.preset) {
            if (lastPreset != null) clear();
            lastPreset = cfg.preset;
        }

        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        int iy = (int) Math.floor(py);
        if (ticks % 40 == 0 || Math.abs(iy - cacheY) >= 6) {
            GROUND_CACHE.clear();
            TOP_CACHE.clear();
            cacheY = iy;
        }

        Preset preset = cfg.preset;
        if (preset.weather && isCovered(world, (int) Math.floor(px), iy, (int) Math.floor(pz))) {
            if (!TRACKED.isEmpty()) clear();
            return;
        }

        // wind with gentle gusts
        double angle = Math.toRadians(cfg.windDirection);
        double gust = 1.0 + 0.45 * Math.sin(ticks * 0.013) + 0.25 * Math.sin(ticks * 0.031 + 1.3);
        double windX = Math.cos(angle) * cfg.wind * 0.04 * gust;
        double windZ = Math.sin(angle) * cfg.wind * 0.04 * gust;

        steer(windX, windZ);

        double area = (cfg.radius / 24.0) * (cfg.radius / 24.0);
        if (cfg.groundLayer) spawnLayer(mc, world, cfg, preset.ground, 0, cfg.groundDensity * area, px, py, pz);
        if (cfg.midLayer) spawnLayer(mc, world, cfg, preset.mid, 1, cfg.midDensity * area, px, py, pz);
        if (cfg.skyLayer) spawnLayer(mc, world, cfg, preset.sky, 2, cfg.skyDensity * area, px, py, pz);
    }

    private static void steer(double windX, double windZ) {
        for (int i = TRACKED.size() - 1; i >= 0; i--) {
            Tracked t = TRACKED.get(i);
            if (!t.particle.isAlive()) {
                int last = TRACKED.size() - 1;
                TRACKED.set(i, TRACKED.get(last));
                TRACKED.remove(last);
                continue;
            }
            t.age++;
            if (t.driven) {
                double sx = Math.sin(t.phase + t.age * 0.09) * t.sway;
                double sz = Math.cos(t.phase * 1.7 + t.age * 0.071) * t.sway;
                double sy = Math.sin(t.phase * 0.6 + t.age * 0.05) * t.sway * 0.4;
                t.particle.setVelocity(t.vx + windX * t.windScale + sx, t.vy + sy, t.vz + windZ * t.windScale + sz);
            }
        }
    }

    private static void spawnLayer(MinecraftClient mc, ClientWorld world, VisualsConfig.Atmosphere cfg,
                                   Preset.Emitter[] emitters, int layer, double density,
                                   double px, double py, double pz) {
        if (density <= 0) return;
        for (Preset.Emitter e : emitters) {
            double c = e.rate() * cfg.intensity * density;
            int n = (int) Math.floor(c);
            if (RNG.nextDouble() < c - n) n++;
            for (int k = 0; k < n; k++) {
                if (TRACKED.size() >= cfg.maxParticles) return;
                spawn(mc, world, cfg, e, layer, px, py, pz);
            }
        }
    }

    private static void spawn(MinecraftClient mc, ClientWorld world, VisualsConfig.Atmosphere cfg,
                              Preset.Emitter e, int layer, double px, double py, double pz) {
        double a = RNG.nextDouble() * Math.PI * 2.0;
        double r = cfg.radius * Math.sqrt(RNG.nextDouble());
        double x = px + Math.cos(a) * r;
        double z = pz + Math.sin(a) * r;
        int bx = (int) Math.floor(x), bz = (int) Math.floor(z), by = (int) Math.floor(py);

        double y;
        if (layer == 2) {
            int top = scanDown(world, TOP_CACHE, bx, bz, by + 24, by - 40);
            if (top == NONE) return;
            y = Math.max(py + 6 + RNG.nextDouble() * 10, top + 2);
        } else {
            int ground = scanDown(world, GROUND_CACHE, bx, bz, by + 3, by - 40);
            if (ground == NONE) return;
            if (layer == 0) y = ground + 0.05 + RNG.nextDouble() * cfg.groundHeight;
            else y = Math.max(ground + 0.3, py - 1.0 + RNG.nextDouble() * 9.0);
        }

        ParticleEffect effect = Particles.lookup(e.primary());
        boolean natural = effect != null && e.natural();
        if (effect == null) {
            effect = Particles.resolve(e.fallback());
        }

        double speed = cfg.speed;
        float vx = (float) (e.vx() * speed + (RNG.nextDouble() - 0.5) * 2.0 * e.jitter());
        float vy = (float) (e.vy() * speed + (RNG.nextDouble() - 0.5) * 2.0 * e.jitter());
        float vz = (float) (e.vz() * speed + (RNG.nextDouble() - 0.5) * 2.0 * e.jitter());

        Particle p = mc.particleManager.addParticle(effect, x, y, z, vx, vy, vz);
        if (p == null) return;

        if (!natural && e.life() > 0) {
            p.setMaxAge((int) (e.life() * (0.75 + RNG.nextDouble() * 0.5)));
        }
        if (p instanceof BillboardParticle bp) {
            bp.scale((float) (cfg.size * e.size()));
            if (cfg.customTint) {
                int rgb = Gfx.hsv(cfg.tintHue, cfg.tintSaturation, 1f);
                bp.setColor(((rgb >> 16) & 0xFF) / 255f, ((rgb >> 8) & 0xFF) / 255f, (rgb & 0xFF) / 255f);
            } else if (!natural && e.tint() >= 0) {
                int rgb = e.tint();
                bp.setColor(((rgb >> 16) & 0xFF) / 255f, ((rgb >> 8) & 0xFF) / 255f, (rgb & 0xFF) / 255f);
            }
        }
        TRACKED.add(new Tracked(p, vx, vy, vz, (float) (e.sway() * speed), (float) e.wind(), !natural));
    }

    /** First solid block below startY (searching down to minY). NONE if the start is inside a block or nothing is found. */
    private static int scanDown(ClientWorld world, HashMap<Long, Integer> cache, int x, int z, int startY, int minY) {
        long key = (((long) x) << 32) ^ (z & 0xFFFFFFFFL);
        Integer cached = cache.get(key);
        if (cached != null) return cached;
        int result = NONE;
        int bottom = Math.max(world.getBottomY(), minY);
        MUT.set(x, startY, z);
        if (world.getBlockState(MUT).isAir()) {
            for (int y = startY - 1; y >= bottom; y--) {
                MUT.set(x, y, z);
                if (!world.getBlockState(MUT).isAir()) {
                    result = y + 1;
                    break;
                }
            }
        }
        cache.put(key, result);
        return result;
    }

    private static boolean isCovered(ClientWorld world, int x, int y, int z) {
        for (int dy = 2; dy <= 26; dy++) {
            MUT.set(x, y + dy, z);
            if (!world.getBlockState(MUT).isAir()) return true;
        }
        return false;
    }
}
