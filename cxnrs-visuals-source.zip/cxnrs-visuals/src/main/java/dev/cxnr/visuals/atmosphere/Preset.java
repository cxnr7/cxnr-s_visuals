package dev.cxnr.visuals.atmosphere;

/**
 * Each preset is a set of emitters for three layers:
 * ground (near the floor), mid (around you) and sky (falling in from above).
 *
 * rate = particles per tick inside a 24 block radius at 100% intensity.
 * Velocities are blocks per tick. "natural" emitters keep the vanilla particle's own movement
 * (cherry petals, fireflies); the rest are steered every tick so wind, sway and speed work.
 */
public enum Preset {
    FIREFLIES("Fireflies", false,
            new Emitter[]{e("firefly", "end_rod", true, 0.7, 0, 0, 0, 0.004, 0.010, 0.3, 140, 1.0, 0xDDFF66)},
            new Emitter[]{e("firefly", "end_rod", true, 0.5, 0, 0, 0, 0.004, 0.010, 0.3, 140, 1.0, 0xDDFF66)},
            new Emitter[]{}),

    FLOWERS("Flowers", true,
            new Emitter[]{e("cherry_leaves", "snowflake", true, 0.9, 0, -0.01, 0, 0.01, 0.02, 2, 120, 1.0, 0xFFB7D5)},
            new Emitter[]{e("cherry_leaves", "snowflake", true, 1.6, 0, -0.02, 0, 0.01, 0.02, 2, 140, 1.0, 0xFFB7D5)},
            new Emitter[]{e("cherry_leaves", "snowflake", true, 2.2, 0, -0.03, 0, 0.01, 0.02, 2, 160, 1.0, 0xFFB7D5)}),

    SNOWFALL("Soft Snow", true,
            new Emitter[]{e("snowflake", "end_rod", false, 1.2, 0, -0.015, 0, 0.004, 0.020, 1.0, 70, 0.9, -1)},
            new Emitter[]{e("snowflake", "end_rod", false, 3.0, 0, -0.05, 0, 0.004, 0.015, 1.0, 100, 1.0, -1)},
            new Emitter[]{e("snowflake", "end_rod", false, 6.0, 0, -0.06, 0, 0.005, 0.012, 1.0, 150, 1.0, -1)}),

    SNOWSTORM("Snowstorm", true,
            new Emitter[]{e("snowflake", "end_rod", false, 6.0, 0, 0.005, 0, 0.010, 0.060, 8.0, 50, 0.8, -1),
                    e("white_ash", "cloud", false, 1.5, 0, 0, 0, 0.010, 0.040, 9.0, 60, 1.6, -1)},
            new Emitter[]{e("snowflake", "end_rod", false, 10.0, 0, -0.11, 0, 0.010, 0.050, 7.0, 70, 1.0, -1)},
            new Emitter[]{e("snowflake", "end_rod", false, 16.0, 0, -0.14, 0, 0.010, 0.030, 6.0, 90, 1.0, -1)}),

    EMBERS("Embers", false,
            new Emitter[]{e("lava", "small_flame", true, 0.8, 0, 0, 0, 0.02, 0, 0.5, 60, 1.0, -1),
                    e("small_flame", "flame", false, 1.6, 0, 0.025, 0, 0.005, 0.020, 1.0, 60, 1.0, -1)},
            new Emitter[]{e("small_flame", "flame", false, 1.4, 0, 0.030, 0, 0.005, 0.025, 1.5, 70, 1.0, -1)},
            new Emitter[]{e("ash", "white_ash", false, 2.0, 0, -0.035, 0, 0.005, 0.020, 1.5, 150, 1.0, -1)}),

    ASHFALL("Ashfall", true,
            new Emitter[]{e("ash", "white_ash", false, 2.0, 0, 0.0, 0, 0.005, 0.025, 2.5, 100, 1.0, -1)},
            new Emitter[]{e("ash", "white_ash", false, 4.0, 0, -0.03, 0, 0.005, 0.020, 2.5, 120, 1.0, -1)},
            new Emitter[]{e("ash", "white_ash", false, 8.0, 0, -0.04, 0, 0.005, 0.020, 2.5, 160, 1.0, -1),
                    e("white_ash", "ash", false, 2.0, 0, -0.03, 0, 0.005, 0.020, 2.5, 160, 1.0, -1)}),

    SPORES("Spores", false,
            new Emitter[]{e("spore_blossom_air", "warped_spore", false, 1.8, 0, 0.006, 0, 0.004, 0.015, 0.6, 150, 1.2, -1)},
            new Emitter[]{e("warped_spore", "end_rod", false, 2.0, 0, 0.008, 0, 0.004, 0.020, 0.6, 150, 1.0, -1),
                    e("crimson_spore", "end_rod", false, 1.0, 0, 0.008, 0, 0.004, 0.020, 0.6, 150, 1.0, -1)},
            new Emitter[]{e("falling_spore_blossom", "spore_blossom_air", true, 1.0, 0, -0.02, 0, 0.004, 0.015, 0.6, 140, 1.0, -1)}),

    STARDUST("Stardust", false,
            new Emitter[]{e("end_rod", "glow", false, 1.8, 0, 0.020, 0, 0.004, 0.015, 0.5, 70, 0.9, -1)},
            new Emitter[]{e("end_rod", "glow", false, 2.5, 0, 0.012, 0, 0.004, 0.025, 0.8, 80, 1.0, -1)},
            new Emitter[]{e("end_rod", "glow", false, 2.0, 0, -0.030, 0, 0.004, 0.020, 1.0, 120, 1.0, -1)}),

    MIST("Mist", false,
            new Emitter[]{e("cloud", "white_ash", false, 3.0, 0, 0, 0, 0.003, 0.015, 0.8, 140, 3.0, -1)},
            new Emitter[]{e("cloud", "white_ash", false, 0.8, 0, 0, 0, 0.003, 0.015, 0.8, 120, 3.0, -1)},
            new Emitter[]{});

    public record Emitter(String primary, String fallback, boolean natural, double rate,
                          double vx, double vy, double vz, double jitter, double sway,
                          double wind, int life, double size, int tint) {
    }

    public final String label;
    /** Weather-like presets stop while you are standing under a roof. */
    public final boolean weather;
    public final Emitter[] ground;
    public final Emitter[] mid;
    public final Emitter[] sky;

    Preset(String label, boolean weather, Emitter[] ground, Emitter[] mid, Emitter[] sky) {
        this.label = label;
        this.weather = weather;
        this.ground = ground;
        this.mid = mid;
        this.sky = sky;
    }

    private static Emitter e(String primary, String fallback, boolean natural, double rate,
                             double vx, double vy, double vz, double jitter, double sway,
                             double wind, int life, double size, int tint) {
        return new Emitter(primary, fallback, natural, rate, vx, vy, vz, jitter, sway, wind, life, size, tint);
    }

    public static String[] labels() {
        Preset[] all = values();
        String[] out = new String[all.length];
        for (int i = 0; i < all.length; i++) out[i] = all[i].label;
        return out;
    }
}
