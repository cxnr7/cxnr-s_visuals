package dev.cxnr.visuals.combat;

import dev.cxnr.visuals.crosshair.CrosshairRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;

import java.util.ArrayList;

/**
 * Works out hits and kills purely on the client: when you swing at something we remember it, and if its
 * health drops soon afterwards that was your hit; if it hits zero after that, that was your kill.
 */
public final class CombatTracker {
    private static final int HIT_WINDOW_TICKS = 12;
    private static final int KILL_WINDOW_TICKS = 40;
    private static final ArrayList<Pending> PENDING = new ArrayList<>();

    private CombatTracker() {}

    private static final class Pending {
        final int id;
        int age;
        int sinceHit = -1;
        float lastHealth;
        String name = "";

        Pending(int id) {
            this.id = id;
        }
    }

    public static void reset() {
        PENDING.clear();
    }

    public static void onAttack(Entity target) {
        CrosshairRenderer.pulse();
        if (!(target instanceof LivingEntity living) || !living.isAlive()) return;
        Pending p = null;
        for (Pending q : PENDING) {
            if (q.id == living.getId()) {
                p = q;
                break;
            }
        }
        if (p == null) {
            if (PENDING.size() >= 12) PENDING.remove(0);
            p = new Pending(living.getId());
            PENDING.add(p);
        }
        p.age = 0;
        p.lastHealth = living.getHealth();
        p.name = living.getName().getString();
    }

    public static void tick(MinecraftClient mc) {
        if (mc.world == null) {
            PENDING.clear();
            return;
        }
        for (int i = PENDING.size() - 1; i >= 0; i--) {
            Pending p = PENDING.get(i);
            Entity entity = mc.world.getEntityById(p.id);
            if (!(entity instanceof LivingEntity living)) {
                PENDING.remove(i);
                continue;
            }
            p.age++;
            if (p.sinceHit >= 0) p.sinceHit++;

            float health = living.getHealth();
            boolean dead = health <= 0f;
            float damage = p.lastHealth - health;
            p.lastHealth = health;

            if (dead && (p.sinceHit >= 0 || p.age <= HIT_WINDOW_TICKS)) {
                Effects.onKill(living, p.name);
                PENDING.remove(i);
                continue;
            }
            if (damage > 0.001f && p.age <= HIT_WINDOW_TICKS) {
                p.sinceHit = 0;
                Effects.onHit(living, damage);
            }
            boolean expired = p.sinceHit >= 0 ? p.sinceHit > KILL_WINDOW_TICKS : p.age > HIT_WINDOW_TICKS;
            if (expired) PENDING.remove(i);
        }
    }
}
