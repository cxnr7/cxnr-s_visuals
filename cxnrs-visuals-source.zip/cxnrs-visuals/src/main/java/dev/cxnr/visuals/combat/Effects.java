package dev.cxnr.visuals.combat;

import dev.cxnr.visuals.config.VisualsConfig;
import dev.cxnr.visuals.gui.Gfx;
import dev.cxnr.visuals.util.Particles;
import dev.cxnr.visuals.util.Sfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleEffect;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

/** Hit and kill effects: HUD markers, popups, screen flash, particle bursts and sounds. */
public final class Effects {
    public static final String[] HIT_MARKERS = {"X", "Plus", "Ring"};
    public static final String[] HIT_PARTICLES = {"Crit", "Sparks", "Stars", "Hearts", "Flames", "Smoke"};
    private static final String[] HIT_PARTICLE_IDS = {"crit", "electric_spark", "end_rod", "heart", "flame", "large_smoke"};
    public static final String[] HIT_SOUNDS = {"Classic ding", "Orb pickup", "Chime", "Pling", "Crit"};
    private static final String[] HIT_SOUND_IDS = {"entity.arrow.hit_player", "entity.experience_orb.pickup",
            "block.amethyst_block.chime", "block.note_block.pling", "entity.player.attack.crit"};

    public static final String[] KILL_PARTICLES = {"Totem", "Souls", "Firework", "Explosion", "Hearts", "Flames", "Portal", "Sparks"};
    private static final String[] KILL_PARTICLE_IDS = {"totem_of_undying", "soul", "firework", "explosion", "heart", "flame", "portal", "electric_spark"};
    public static final String[] KILL_SOUNDS = {"Level up", "Totem", "Thunder", "Firework blast", "Challenge"};
    private static final String[] KILL_SOUND_IDS = {"entity.player.levelup", "item.totem.use", "entity.lightning_bolt.thunder",
            "entity.firework_rocket.blast", "ui.toast.challenge_complete"};

    private static final int HIT = 0, KILL = 1, FLASH = 2, DAMAGE = 3, MESSAGE = 4;
    private static final Random RNG = new Random();
    private static final ArrayList<Ev> EVENTS = new ArrayList<>();

    private Effects() {}

    private record Ev(int kind, long start, long duration, float value, String text, int seed) {
    }

    public static void reset() {
        EVENTS.clear();
    }

    // ---------------------------------------------------------------- triggers

    public static void onHit(LivingEntity target, float damage) {
        VisualsConfig.Hit c = VisualsConfig.get().hit;
        if (!c.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        if (c.marker) add(new Ev(HIT, now, c.markerDuration * 1_000_000L, 0f, null, 0));
        if (c.damageText && damage > 0f) {
            add(new Ev(DAMAGE, now, 900_000_000L, damage, String.format(Locale.ROOT, "-%.1f", damage), RNG.nextInt(1000)));
        }
        if (c.particles) {
            burst(mc, HIT_PARTICLE_IDS[c.particleStyle], target, c.particleCount, 0.10 * c.particleSpeed);
        }
        if (c.sound) Sfx.play(HIT_SOUND_IDS[c.soundIndex], c.volume, c.pitch);
    }

    public static void onKill(LivingEntity target, String name) {
        VisualsConfig.Kill c = VisualsConfig.get().kill;
        if (!c.enabled) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        long now = System.nanoTime();
        if (c.marker) add(new Ev(KILL, now, c.markerDuration * 1_000_000L, 0f, null, 0));
        if (c.flash) add(new Ev(FLASH, now, 550_000_000L, c.flashStrength, null, 0));
        if (c.message) add(new Ev(MESSAGE, now, 1_600_000_000L, 0f, name, 0));
        if (c.particles) {
            burst(mc, KILL_PARTICLE_IDS[c.particleStyle], target, c.particleCount, 0.22 * c.particleSpeed);
        }
        if (c.sound) Sfx.play(KILL_SOUND_IDS[c.soundIndex], c.volume, c.pitch);
    }

    private static void add(Ev e) {
        if (EVENTS.size() >= 24) EVENTS.remove(0);
        EVENTS.add(e);
    }

    private static void burst(MinecraftClient mc, String id, LivingEntity target, int count, double speed) {
        if (mc.world == null) return;
        ParticleEffect effect = Particles.resolve(id);
        double cx = target.getX();
        double cy = target.getY() + target.getHeight() * 0.55;
        double cz = target.getZ();
        double spread = Math.max(0.2, target.getWidth() * 0.5);
        for (int i = 0; i < count; i++) {
            double dx = RNG.nextGaussian(), dy = RNG.nextGaussian(), dz = RNG.nextGaussian();
            double len = Math.max(0.001, Math.sqrt(dx * dx + dy * dy + dz * dz));
            double s = speed * (0.4 + RNG.nextDouble() * 0.8);
            mc.particleManager.addParticle(effect,
                    cx + dx * spread * 0.4, cy + dy * spread * 0.4, cz + dz * spread * 0.4,
                    dx / len * s, dy / len * s + speed * 0.3, dz / len * s);
        }
    }

    // ---------------------------------------------------------------- HUD

    public static void renderHud(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        long now = System.nanoTime();
        for (int i = EVENTS.size() - 1; i >= 0; i--) {
            if (now - EVENTS.get(i).start() > EVENTS.get(i).duration()) EVENTS.remove(i);
        }
        if (EVENTS.isEmpty()) return;

        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        int cx = w / 2, cy = h / 2;
        VisualsConfig cfg = VisualsConfig.get();

        for (Ev e : EVENTS) {
            if (e.kind() != FLASH) continue;
            float t = progress(e, now);
            float fade = (1f - t) * (1f - t);
            int rgb = Gfx.hsv(cfg.kill.flashHue, cfg.kill.flashSaturation, 1f);
            int strong = Gfx.withAlpha(rgb, Math.round(255 * e.value() * fade));
            int none = Gfx.withAlpha(rgb, 0);
            if ((strong >>> 24) >= 4) {
                ctx.fillGradient(0, 0, w, h / 2, strong, none);
                ctx.fillGradient(0, h / 2, w, h, none, strong);
                ctx.fill(0, 0, w, h, Gfx.mulAlpha(strong, 0.18f));
            }
        }

        for (Ev e : EVENTS) {
            float t = progress(e, now);
            float fade = 1f - t * t;
            if (e.kind() == HIT) {
                VisualsConfig.Hit c = cfg.hit;
                int rgb = Gfx.hsv(c.markerHue, c.markerSaturation, 1f);
                int gap = 3 + Math.round(t * 3f);
                drawMarker(ctx, cx, cy, c.markerStyle, gap, c.markerSize, 2, rgb, fade);
            } else if (e.kind() == KILL) {
                VisualsConfig.Kill c = cfg.kill;
                int rgb = Gfx.hsv(c.markerHue, c.markerSaturation, 1f);
                float pop = Math.min(1f, t * 6f);
                int len = Math.round(c.markerSize * (0.6f + 0.4f * pop));
                drawMarker(ctx, cx, cy, 0, 4 + Math.round(t * 4f), len, 3, rgb, fade);
                drawRing(ctx, cx, cy, 6 + Math.round(t * 22f), 1, rgb, fade * 0.8f);
            }
        }

        var font = mc.textRenderer;
        for (Ev e : EVENTS) {
            float t = progress(e, now);
            int alpha = Math.round(255 * (1f - t * t));
            if (alpha < 8) continue;
            if (e.kind() == DAMAGE) {
                int x = cx + 14 + (e.seed() % 11) - 5;
                int y = cy - 10 - Math.round(t * 16f);
                ctx.drawText(font, e.text(), x, y, (alpha << 24) | 0xFF5560, true);
            } else if (e.kind() == MESSAGE) {
                String text = "Eliminated " + e.text();
                int x = cx - font.getWidth(text) / 2;
                int y = cy + 26 - Math.round(t * 6f);
                ctx.drawText(font, text, x, y, (alpha << 24) | 0xFFE0E0, true);
            }
        }
    }

    private static float progress(Ev e, long now) {
        return Math.min(1f, Math.max(0f, (now - e.start()) / (float) e.duration()));
    }

    private static void drawMarker(DrawContext ctx, int cx, int cy, int style, int gap, int len, int thick, int rgb, float alpha) {
        int a = Math.round(255 * alpha);
        if (a < 4) return;
        int color = (a << 24) | (rgb & 0xFFFFFF);
        int shadow = Gfx.argb(a * 2 / 3, 0, 0, 0);
        if (style == 2) {
            drawRing(ctx, cx, cy, gap + len, thick, rgb, alpha);
            return;
        }
        for (int pass = 0; pass < 2; pass++) {
            int c = pass == 0 ? shadow : color;
            int grow = pass == 0 ? 1 : 0;
            int t = thick + grow * 2;
            for (int k = 0; k < len; k++) {
                int d = gap + k;
                if (style == 0) {
                    for (int sx = -1; sx <= 1; sx += 2) {
                        for (int sy = -1; sy <= 1; sy += 2) {
                            int x = cx + sx * d - t / 2;
                            int y = cy + sy * d - t / 2;
                            ctx.fill(x, y, x + t, y + t, c);
                        }
                    }
                } else {
                    int h = t / 2;
                    ctx.fill(cx - h, cy - d - t / 2, cx - h + t, cy - d - t / 2 + t, c);
                    ctx.fill(cx - h, cy + d - t / 2, cx - h + t, cy + d - t / 2 + t, c);
                    ctx.fill(cx - d - t / 2, cy - h, cx - d - t / 2 + t, cy - h + t, c);
                    ctx.fill(cx + d - t / 2, cy - h, cx + d - t / 2 + t, cy - h + t, c);
                }
            }
        }
    }

    public static void drawRing(DrawContext ctx, int cx, int cy, int radius, int thick, int rgb, float alpha) {
        int a = Math.round(255 * alpha);
        if (a < 4 || radius < 1) return;
        int color = (a << 24) | (rgb & 0xFFFFFF);
        int n = Math.max(16, Math.round(radius * 7f));
        for (int i = 0; i < n; i++) {
            double ang = (i / (double) n) * Math.PI * 2.0;
            int x = cx + (int) Math.round(Math.cos(ang) * radius) - thick / 2;
            int y = cy + (int) Math.round(Math.sin(ang) * radius) - thick / 2;
            ctx.fill(x, y, x + thick, y + thick, color);
        }
    }
}
