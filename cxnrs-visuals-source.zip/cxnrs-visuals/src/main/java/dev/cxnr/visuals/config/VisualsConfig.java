package dev.cxnr.visuals.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import dev.cxnr.visuals.atmosphere.Preset;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/** Everything the menu can change. Saved as config/cxnrs-visuals.json. */
public final class VisualsConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static VisualsConfig instance = new VisualsConfig();

    // ---- interface ----
    public int openKey = 344; // GLFW_KEY_RIGHT_SHIFT
    public float uiHue = 0.56f;
    public boolean uiBlur = true;

    public Atmosphere atmosphere = new Atmosphere();
    public Crosshair crosshair = new Crosshair();
    public Hit hit = new Hit();
    public Kill kill = new Kill();

    public static final class Atmosphere {
        public boolean enabled = true;
        public Preset preset = Preset.FIREFLIES;
        public float intensity = 1.0f;
        public float speed = 1.0f;
        public float size = 1.0f;
        public float wind = 0.5f;
        public float windDirection = 40f;
        public int radius = 24;
        public int maxParticles = 3000;
        public boolean groundLayer = true;
        public float groundDensity = 1.0f;
        public int groundHeight = 3;
        public boolean midLayer = true;
        public float midDensity = 1.0f;
        public boolean skyLayer = true;
        public float skyDensity = 1.0f;
        public boolean customTint = false;
        public float tintHue = 0.55f;
        public float tintSaturation = 0.6f;
    }

    public static final class Crosshair {
        public boolean enabled = false;
        public int style = 0;
        public int size = 6;
        public int thickness = 2;
        public int gap = 3;
        public boolean outline = true;
        public int colorMode = 0; // 0 solid, 1 rainbow, 2 red when aiming at an entity
        public float hue = 0.0f;
        public float saturation = 0.0f; // 0 = white
        public float opacity = 1.0f;
        public boolean dynamic = true;
        public float dynamicAmount = 1.0f;
        public boolean cooldownBar = false;
    }

    public static final class Hit {
        public boolean enabled = true;
        public boolean marker = true;
        public int markerStyle = 0;
        public int markerSize = 5;
        public int markerDuration = 350;
        public float markerHue = 0.0f;
        public float markerSaturation = 0.0f;
        public boolean damageText = true;
        public boolean particles = true;
        public int particleStyle = 0;
        public int particleCount = 8;
        public float particleSpeed = 1.0f;
        public boolean sound = true;
        public int soundIndex = 0;
        public float volume = 0.6f;
        public float pitch = 1.2f;
    }

    public static final class Kill {
        public boolean enabled = true;
        public boolean marker = true;
        public int markerSize = 8;
        public int markerDuration = 700;
        public float markerHue = 0.0f;
        public float markerSaturation = 0.85f;
        public boolean flash = true;
        public float flashHue = 0.0f;
        public float flashSaturation = 0.9f;
        public float flashStrength = 0.35f;
        public boolean message = true;
        public boolean particles = true;
        public int particleStyle = 0;
        public int particleCount = 30;
        public float particleSpeed = 1.0f;
        public boolean sound = true;
        public int soundIndex = 0;
        public float volume = 0.8f;
        public float pitch = 1.0f;
    }

    // ---- load / save ----

    public static VisualsConfig get() {
        return instance;
    }

    public static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("cxnrs-visuals.json");
    }

    public static void load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader r = Files.newBufferedReader(p)) {
                VisualsConfig loaded = GSON.fromJson(r, VisualsConfig.class);
                if (loaded != null) instance = loaded;
            } catch (Exception e) {
                System.err.println("[cxnr's-visuals] Could not read the config, using defaults: " + e);
            }
        }
        instance.sanitize();
        save();
    }

    public static void save() {
        Path p = path();
        try {
            Files.createDirectories(p.getParent());
            try (Writer w = Files.newBufferedWriter(p)) {
                GSON.toJson(instance, w);
            }
        } catch (IOException e) {
            System.err.println("[cxnr's-visuals] Could not save the config: " + e);
        }
    }

    public void sanitize() {
        if (atmosphere == null) atmosphere = new Atmosphere();
        if (crosshair == null) crosshair = new Crosshair();
        if (hit == null) hit = new Hit();
        if (kill == null) kill = new Kill();
        if (openKey < 32 || openKey > 348) openKey = 344;
        uiHue = clamp(uiHue, 0f, 1f);

        Atmosphere a = atmosphere;
        if (a.preset == null) a.preset = Preset.FIREFLIES;
        a.intensity = clamp(a.intensity, 0f, 3f);
        a.speed = clamp(a.speed, 0.2f, 3f);
        a.size = clamp(a.size, 0.3f, 3f);
        a.wind = clamp(a.wind, 0f, 2f);
        a.windDirection = clamp(a.windDirection, 0f, 360f);
        a.radius = clamp(a.radius, 8, 48);
        a.maxParticles = clamp(a.maxParticles, 200, 8000);
        a.groundDensity = clamp(a.groundDensity, 0f, 3f);
        a.midDensity = clamp(a.midDensity, 0f, 3f);
        a.skyDensity = clamp(a.skyDensity, 0f, 3f);
        a.groundHeight = clamp(a.groundHeight, 1, 10);
        a.tintHue = clamp(a.tintHue, 0f, 1f);
        a.tintSaturation = clamp(a.tintSaturation, 0f, 1f);

        Crosshair c = crosshair;
        c.style = clamp(c.style, 0, 5);
        c.size = clamp(c.size, 1, 30);
        c.thickness = clamp(c.thickness, 1, 6);
        c.gap = clamp(c.gap, 0, 16);
        c.colorMode = clamp(c.colorMode, 0, 2);
        c.hue = clamp(c.hue, 0f, 1f);
        c.saturation = clamp(c.saturation, 0f, 1f);
        c.opacity = clamp(c.opacity, 0.1f, 1f);
        c.dynamicAmount = clamp(c.dynamicAmount, 0f, 3f);

        Hit h = hit;
        h.markerStyle = clamp(h.markerStyle, 0, 2);
        h.markerSize = clamp(h.markerSize, 2, 16);
        h.markerDuration = clamp(h.markerDuration, 100, 1500);
        h.markerHue = clamp(h.markerHue, 0f, 1f);
        h.markerSaturation = clamp(h.markerSaturation, 0f, 1f);
        h.particleStyle = clamp(h.particleStyle, 0, 5);
        h.particleCount = clamp(h.particleCount, 1, 60);
        h.particleSpeed = clamp(h.particleSpeed, 0.2f, 3f);
        h.soundIndex = clamp(h.soundIndex, 0, 4);
        h.volume = clamp(h.volume, 0f, 1f);
        h.pitch = clamp(h.pitch, 0.5f, 2f);

        Kill k = kill;
        k.markerSize = clamp(k.markerSize, 2, 20);
        k.markerDuration = clamp(k.markerDuration, 200, 2000);
        k.markerHue = clamp(k.markerHue, 0f, 1f);
        k.markerSaturation = clamp(k.markerSaturation, 0f, 1f);
        k.flashHue = clamp(k.flashHue, 0f, 1f);
        k.flashSaturation = clamp(k.flashSaturation, 0f, 1f);
        k.flashStrength = clamp(k.flashStrength, 0.05f, 1f);
        k.particleStyle = clamp(k.particleStyle, 0, 7);
        k.particleCount = clamp(k.particleCount, 1, 150);
        k.particleSpeed = clamp(k.particleSpeed, 0.2f, 3f);
        k.soundIndex = clamp(k.soundIndex, 0, 4);
        k.volume = clamp(k.volume, 0f, 1f);
        k.pitch = clamp(k.pitch, 0.5f, 2f);
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : Math.min(v, hi);
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : Math.min(v, hi);
    }
}
