package dev.cxnr.visuals.crosshair;

import dev.cxnr.visuals.config.VisualsConfig;
import dev.cxnr.visuals.gui.Gfx;
import dev.cxnr.visuals.gui.VisualsScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/** Draws the custom crosshair (and the little preview in the menu). */
public final class CrosshairRenderer {
    public static final String[] STYLES = {"Cross", "Dot", "Ring", "Cross + Dot", "X", "Square"};
    public static final String[] COLOR_MODES = {"Solid", "Rainbow", "Red on target"};

    private static float smooth;
    private static float pulse;

    private CrosshairRenderer() {}

    /** Called when you swing, makes the crosshair kick outwards a little. */
    public static void pulse() {
        pulse = 1f;
    }

    public static void renderHud(DrawContext ctx) {
        VisualsConfig.Crosshair c = VisualsConfig.get().crosshair;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!c.enabled || mc.player == null || mc.options.hudHidden) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        if (mc.currentScreen != null && !(mc.currentScreen instanceof VisualsScreen)) return;

        float target = 0f;
        if (c.dynamic) {
            Vec3d v = mc.player.getVelocity();
            double horizontal = Math.sqrt(v.x * v.x + v.z * v.z);
            target = (float) (horizontal * 18.0 + (mc.player.isOnGround() ? 0 : 3) + (mc.player.isSprinting() ? 1.5 : 0));
            target = (target + pulse * 4f) * c.dynamicAmount;
        }
        smooth += (target - smooth) * 0.25f;
        pulse = Math.max(0f, pulse - 0.08f);

        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;
        boolean onTarget = mc.crosshairTarget != null && mc.crosshairTarget.getType() == HitResult.Type.ENTITY;
        int rgb = colorFor(c, onTarget);
        draw(ctx, cx, cy, c, smooth, rgb, c.opacity);

        if (c.cooldownBar) {
            float cd = mc.player.getAttackCooldownProgress(0f);
            if (cd < 1f) {
                int y = cy + c.gap + c.size + Math.round(smooth) + 7;
                int a = Math.max(4, Math.round(255 * c.opacity));
                ctx.fill(cx - 11, y - 1, cx + 11, y + 3, Gfx.argb(a * 2 / 3, 0, 0, 0));
                ctx.fill(cx - 10, y, cx - 10 + Math.round(20 * cd), y + 2, (a << 24) | (rgb & 0xFFFFFF));
            }
        }
    }

    public static int colorFor(VisualsConfig.Crosshair c, boolean onTarget) {
        switch (c.colorMode) {
            case 1: {
                float h = (float) ((System.nanoTime() / 3_000_000_000.0) % 1.0);
                return Gfx.hsv(h, 0.85f, 1f);
            }
            case 2:
                if (onTarget) return 0xFF4040;
                return Gfx.hsv(c.hue, c.saturation, 1f);
            default:
                return Gfx.hsv(c.hue, c.saturation, 1f);
        }
    }

    public static void draw(DrawContext ctx, int cx, int cy, VisualsConfig.Crosshair c, float spread, int rgb, float opacity) {
        int t = Math.max(1, c.thickness);
        int s = Math.max(1, c.size);
        int g = Math.max(0, Math.round(c.gap + spread));
        List<int[]> r = new ArrayList<>(24);
        switch (c.style) {
            case 1 -> {
                int d = Math.max(2, Math.round(s * 0.5f));
                r.add(rect(cx - d / 2, cy - d / 2, d, d));
            }
            case 2 -> ring(r, cx, cy, Math.max(3, s + g / 2), t);
            case 3 -> {
                cross(r, cx, cy, s, t, g);
                int d = Math.max(2, t + 1);
                r.add(rect(cx - d / 2, cy - d / 2, d, d));
            }
            case 4 -> {
                int h = t / 2;
                for (int k = 0; k < s; k++) {
                    int d = g + k;
                    r.add(rect(cx + d - h, cy + d - h, t, t));
                    r.add(rect(cx - d - h, cy + d - h, t, t));
                    r.add(rect(cx + d - h, cy - d - h, t, t));
                    r.add(rect(cx - d - h, cy - d - h, t, t));
                }
            }
            case 5 -> {
                int half = Math.max(2, s / 2 + g);
                r.add(rect(cx - half, cy - half, half * 2, t));
                r.add(rect(cx - half, cy + half - t, half * 2, t));
                r.add(rect(cx - half, cy - half + t, t, Math.max(1, half * 2 - 2 * t)));
                r.add(rect(cx + half - t, cy - half + t, t, Math.max(1, half * 2 - 2 * t)));
            }
            default -> cross(r, cx, cy, s, t, g);
        }

        int a = Math.max(4, Math.round(255 * opacity));
        if (c.outline) {
            int oc = Gfx.argb(Math.max(4, a * 3 / 4), 0, 0, 0);
            for (int[] q : r) ctx.fill(q[0] - 1, q[1] - 1, q[0] + q[2] + 1, q[1] + q[3] + 1, oc);
        }
        int fc = (a << 24) | (rgb & 0xFFFFFF);
        for (int[] q : r) ctx.fill(q[0], q[1], q[0] + q[2], q[1] + q[3], fc);
    }

    private static int[] rect(int x, int y, int w, int h) {
        return new int[]{x, y, w, h};
    }

    private static void cross(List<int[]> r, int cx, int cy, int s, int t, int g) {
        int h = t / 2;
        r.add(rect(cx - h, cy - g - s, t, s));
        r.add(rect(cx - h, cy + g, t, s));
        r.add(rect(cx - g - s, cy - h, s, t));
        r.add(rect(cx + g, cy - h, s, t));
    }

    private static void ring(List<int[]> r, int cx, int cy, int radius, int t) {
        int n = Math.max(16, Math.round(radius * 8f));
        for (int i = 0; i < n; i++) {
            double ang = (i / (double) n) * Math.PI * 2.0;
            r.add(rect(cx + (int) Math.round(Math.cos(ang) * radius) - t / 2,
                    cy + (int) Math.round(Math.sin(ang) * radius) - t / 2, t, t));
        }
    }
}
