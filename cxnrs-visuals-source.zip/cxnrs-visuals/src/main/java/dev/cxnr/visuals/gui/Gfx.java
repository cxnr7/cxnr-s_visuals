package dev.cxnr.visuals.gui;

import dev.cxnr.visuals.config.VisualsConfig;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

/** Small drawing helpers: colours, rounded rectangles and text. Everything is built from plain fills. */
public final class Gfx {
    public static final int TEXT = 0xFFEAF0FF;
    public static final int TEXT_DIM = 0xFF9AA6C0;
    public static final int TEXT_OFF = 0xFF6B7488;

    private Gfx() {}

    // ---------------------------------------------------------------- colours

    public static int clamp255(int v) {
        return v < 0 ? 0 : Math.min(v, 255);
    }

    public static int argb(int a, int r, int g, int b) {
        return (clamp255(a) << 24) | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(b);
    }

    public static int withAlpha(int rgb, int a) {
        return (clamp255(a) << 24) | (rgb & 0xFFFFFF);
    }

    public static int mulAlpha(int argb, float m) {
        int a = Math.round(((argb >>> 24) & 0xFF) * m);
        return (clamp255(a) << 24) | (argb & 0xFFFFFF);
    }

    public static int lerpColor(int from, int to, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int a = Math.round(((from >>> 24) & 0xFF) * (1 - t) + ((to >>> 24) & 0xFF) * t);
        int r = Math.round(((from >> 16) & 0xFF) * (1 - t) + ((to >> 16) & 0xFF) * t);
        int g = Math.round(((from >> 8) & 0xFF) * (1 - t) + ((to >> 8) & 0xFF) * t);
        int b = Math.round((from & 0xFF) * (1 - t) + (to & 0xFF) * t);
        return argb(a, r, g, b);
    }

    /** h, s, v all 0..1. Returns 0xRRGGBB. */
    public static int hsv(float h, float s, float v) {
        h = h - (float) Math.floor(h);
        s = Math.max(0f, Math.min(1f, s));
        v = Math.max(0f, Math.min(1f, v));
        float c = v * s;
        float x = c * (1f - Math.abs((h * 6f) % 2f - 1f));
        float m = v - c;
        float r, g, b;
        switch ((int) (h * 6f)) {
            case 0: r = c; g = x; b = 0; break;
            case 1: r = x; g = c; b = 0; break;
            case 2: r = 0; g = c; b = x; break;
            case 3: r = 0; g = x; b = c; break;
            case 4: r = x; g = 0; b = c; break;
            default: r = c; g = 0; b = x; break;
        }
        int ri = Math.round((r + m) * 255f), gi = Math.round((g + m) * 255f), bi = Math.round((b + m) * 255f);
        return (clamp255(ri) << 16) | (clamp255(gi) << 8) | clamp255(bi);
    }

    /** The menu accent colour (from the Interface tab) with the given alpha. */
    public static int accent(int alpha) {
        return withAlpha(hsv(VisualsConfig.get().uiHue, 0.55f, 1f), alpha);
    }

    // ---------------------------------------------------------------- shapes

    private static int inset(int r, int i) {
        double dy = r - i - 0.5;
        return (int) Math.round(r - Math.sqrt(Math.max(0.0, r * (double) r - dy * dy)));
    }

    /** Filled rounded rectangle without overlapping fills, so translucent colours stay even. */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 0 || h <= 0) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int dx = inset(r, i);
            c.fill(x + dx, y + i, x + w - dx, y + i + 1, color);
            c.fill(x + dx, y + h - 1 - i, x + w - dx, y + h - i, color);
        }
    }

    /** One pixel wide rounded outline. */
    public static void rborder(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (w <= 2 || h <= 2) return;
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 1) {
            c.fill(x, y, x + w, y + 1, color);
            c.fill(x, y + h - 1, x + w, y + h, color);
            c.fill(x, y + 1, x + 1, y + h - 1, color);
            c.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
            return;
        }
        c.fill(x + r, y, x + w - r, y + 1, color);
        c.fill(x + r, y + h - 1, x + w - r, y + h, color);
        c.fill(x, y + r, x + 1, y + h - r, color);
        c.fill(x + w - 1, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            int a = inset(r, i);
            int b = i == 0 ? r : inset(r, i - 1);
            int end = Math.max(a + 1, b);
            c.fill(x + a, y + i, x + end, y + i + 1, color);
            c.fill(x + w - end, y + i, x + w - a, y + i + 1, color);
            c.fill(x + a, y + h - 1 - i, x + end, y + h - i, color);
            c.fill(x + w - end, y + h - 1 - i, x + w - a, y + h - i, color);
        }
    }

    // ---------------------------------------------------------------- text

    public static void text(DrawContext c, TextRenderer f, String s, int x, int y, int color) {
        c.drawText(f, s, x, y, color, true);
    }

    public static void textCentered(DrawContext c, TextRenderer f, String s, int cx, int y, int color) {
        c.drawText(f, s, cx - f.getWidth(s) / 2, y, color, true);
    }

    public static void textRight(DrawContext c, TextRenderer f, String s, int right, int y, int color) {
        c.drawText(f, s, right - f.getWidth(s), y, color, true);
    }
}
