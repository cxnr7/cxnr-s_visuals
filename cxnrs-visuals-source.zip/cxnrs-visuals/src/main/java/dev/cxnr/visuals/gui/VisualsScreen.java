package dev.cxnr.visuals.gui;

import dev.cxnr.visuals.CxnrVisuals;
import dev.cxnr.visuals.atmosphere.AtmosphereManager;
import dev.cxnr.visuals.atmosphere.Preset;
import dev.cxnr.visuals.combat.Effects;
import dev.cxnr.visuals.config.VisualsConfig;
import dev.cxnr.visuals.crosshair.CrosshairRenderer;
import dev.cxnr.visuals.util.Keys;
import dev.cxnr.visuals.util.Sfx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * The glass menu. All input is read straight from GLFW each frame instead of overriding the
 * click/key handlers, so it keeps working no matter how Mojang reshuffles those signatures.
 */
public final class VisualsScreen extends Screen {
    private static final String[] TABS = {"Atmosphere", "Crosshair", "Hit Effects", "Kill Effects", "Interface"};
    private static final int ROW_GAP = 2;
    private static int lastTab;

    private final List<List<Row>> pages = new ArrayList<>();
    private int tab = lastTab;
    private int scroll;
    private boolean prevLeft, prevRight, prevKey;
    private boolean keyListening;
    private Row dragRow;
    private boolean dragScroll;
    private long lastFrame = System.nanoTime();
    private final long openedAt = System.nanoTime();

    // geometry of the last frame (used for hit testing)
    private int sideX, sideY, sideW = 100, tabH = 26;
    private int sbX, sbY, sbH, thumbH, maxScroll;
    private boolean sbVisible;

    public VisualsScreen() {
        super(Text.literal("cxnr's-visuals"));
        pages.add(atmosphereRows());
        pages.add(crosshairRows());
        pages.add(hitRows());
        pages.add(killRows());
        pages.add(interfaceRows());
        MinecraftClient mc = MinecraftClient.getInstance();
        long win = mc.getWindow().getHandle();
        prevLeft = Keys.mouseDown(win, 0);
        prevRight = Keys.mouseDown(win, 1);
        prevKey = Keys.isDown(win, VisualsConfig.get().openKey);
    }

    @Override
    public boolean shouldPause() {
        return false; // keep the world running so you can watch presets live
    }

    @Override
    public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
        if (VisualsConfig.get().uiBlur) this.applyBlur(ctx);
        ctx.fillGradient(0, 0, this.width, this.height, 0x40080C16, 0x60080C16);
    }

    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll -= (int) Math.signum(verticalAmount);
        return true;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);

        MinecraftClient mc = MinecraftClient.getInstance();
        TextRenderer font = mc.textRenderer;
        VisualsConfig cfg = VisualsConfig.get();
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastFrame) / 1e9f);
        lastFrame = now;
        long win = mc.getWindow().getHandle();

        // press the open key again to close
        boolean keyDown = Keys.isDown(win, cfg.openKey);
        if (!keyListening && keyDown && !prevKey) {
            CxnrVisuals.openKeyWasDown = true;
            this.close();
            return;
        }
        prevKey = keyDown;

        // ---- layout
        float open = Math.min(1f, (now - openedAt) / 180_000_000f);
        float ease = 1f - (1f - open) * (1f - open);
        int pw = Math.min(this.width - 20, 540);
        int ph = Math.min(this.height - 20, 310);
        int px = (this.width - pw) / 2;
        int py = (this.height - ph) / 2 + Math.round((1f - ease) * 14f);

        // ---- glass panel
        Gfx.rrect(ctx, px - 3, py, pw + 6, ph + 6, 13, 0x16000000);
        Gfx.rrect(ctx, px - 1, py + 1, pw + 2, ph + 3, 12, 0x24000000);
        Gfx.rrect(ctx, px, py, pw, ph, 11, 0x84101624);
        ctx.fillGradient(px + 11, py + 1, px + pw - 11, py + ph / 3, 0x26FFFFFF, 0x00FFFFFF);
        Gfx.rborder(ctx, px, py, pw, ph, 11, 0x55FFFFFF);
        ctx.fill(px + 20, py + 1, px + pw - 20, py + 2, Gfx.accent(0x99));

        // ---- header
        Gfx.text(ctx, font, "cxnr's-visuals", px + 16, py + 12, Gfx.accent(0xFF));
        Gfx.textRight(ctx, font, Keys.name(cfg.openKey) + " closes this menu", px + pw - 16, py + 12, Gfx.TEXT_OFF);
        ctx.fill(px + 12, py + 30, px + pw - 12, py + 31, 0x22FFFFFF);

        Frame fr = new Frame();
        fr.g = ctx;
        fr.f = font;
        fr.mx = mouseX;
        fr.my = mouseY;
        fr.dt = dt;
        fr.win = win;
        fr.s = this;

        // ---- sidebar
        sideX = px + 10;
        sideY = py + 40;
        for (int i = 0; i < TABS.length; i++) {
            int ty = sideY + i * (tabH + 3);
            boolean active = i == tab;
            boolean hover = mouseX >= sideX && mouseX < sideX + sideW && mouseY >= ty && mouseY < ty + tabH;
            if (active) {
                Gfx.rrect(ctx, sideX, ty, sideW, tabH, 6, Gfx.accent(0x40));
                Gfx.rborder(ctx, sideX, ty, sideW, tabH, 6, Gfx.accent(0x88));
                ctx.fill(sideX + 3, ty + 6, sideX + 5, ty + tabH - 6, Gfx.accent(0xFF));
            } else if (hover) {
                Gfx.rrect(ctx, sideX, ty, sideW, tabH, 6, 0x16FFFFFF);
            }
            Gfx.text(ctx, font, TABS[i], sideX + 12, ty + 9, active ? 0xFFFFFFFF : (hover ? Gfx.TEXT : Gfx.TEXT_DIM));
            Boolean on = tabEnabled(i);
            if (on != null) {
                int dx = sideX + sideW - 12, dy = ty + tabH / 2 - 2;
                Gfx.rrect(ctx, dx, dy, 5, 5, 2, on ? Gfx.accent(0xFF) : 0x55FFFFFF);
            }
        }

        // ---- content
        int cx0 = px + 10 + sideW + 14;
        int cy0 = py + 38;
        int cw = pw - (cx0 - px) - 14;
        int ch = ph - 38 - 26;
        List<Row> rows = pages.get(tab);

        maxScroll = computeMaxScroll(rows, ch);
        scroll = Math.max(0, Math.min(scroll, maxScroll));
        sbVisible = maxScroll > 0;
        int rowW = cw - (sbVisible ? 10 : 0);

        for (Row r : rows) r.visible = false;
        int y = cy0, drawn = 0;
        for (int i = scroll; i < rows.size(); i++) {
            Row r = rows.get(i);
            int h = r.height();
            if (y + h > cy0 + ch) break;
            r.rx = cx0;
            r.ry = y;
            r.rw = rowW;
            r.visible = true;
            r.draw(fr);
            y += h + ROW_GAP;
            drawn++;
        }

        if (sbVisible) {
            sbX = cx0 + cw - 4;
            sbY = cy0;
            sbH = ch;
            thumbH = Math.max(18, Math.round(ch * (drawn / (float) rows.size())));
            int thumbY = sbY + Math.round((sbH - thumbH) * (scroll / (float) maxScroll));
            Gfx.rrect(ctx, sbX, sbY, 4, sbH, 2, 0x16FFFFFF);
            boolean hot = dragScroll || (mouseX >= sbX - 4 && mouseX <= sbX + 8 && mouseY >= thumbY && mouseY < thumbY + thumbH);
            Gfx.rrect(ctx, sbX, thumbY, 4, thumbH, 2, Gfx.accent(hot ? 0xE0 : 0x99));
        }

        // ---- footer
        ctx.fill(px + 12, py + ph - 24, px + pw - 12, py + ph - 23, 0x16FFFFFF);
        Gfx.text(ctx, font, "Scroll for more  |  Right-click a selector to go back", cx0 - sideW - 4, py + ph - 17, Gfx.TEXT_OFF);

        // ---- input (after drawing so hit boxes match what you see)
        boolean left = Keys.mouseDown(win, 0);
        boolean right = Keys.mouseDown(win, 1);
        handleInput(fr, rows, left, right);
    }

    private Boolean tabEnabled(int i) {
        VisualsConfig c = VisualsConfig.get();
        switch (i) {
            case 0: return c.atmosphere.enabled;
            case 1: return c.crosshair.enabled;
            case 2: return c.hit.enabled;
            case 3: return c.kill.enabled;
            default: return null;
        }
    }

    private static int computeMaxScroll(List<Row> rows, int viewH) {
        int used = 0, idx = rows.size();
        while (idx > 0) {
            int h = rows.get(idx - 1).height();
            int next = used == 0 ? h : used + ROW_GAP + h;
            if (next > viewH) break;
            used = next;
            idx--;
        }
        return idx;
    }

    private void scrollFromMouse(int my) {
        if (maxScroll <= 0) return;
        float t = (my - sbY - thumbH / 2f) / Math.max(1f, (sbH - thumbH));
        scroll = Math.max(0, Math.min(maxScroll, Math.round(t * maxScroll)));
    }

    private void handleInput(Frame fr, List<Row> rows, boolean left, boolean right) {
        boolean leftPressed = left && !prevLeft;
        boolean rightPressed = right && !prevRight;
        boolean leftReleased = !left && prevLeft;
        prevLeft = left;
        prevRight = right;
        int mx = fr.mx, my = fr.my;

        if (leftPressed) {
            for (int i = 0; i < TABS.length; i++) {
                int ty = sideY + i * (tabH + 3);
                if (mx >= sideX && mx < sideX + sideW && my >= ty && my < ty + tabH) {
                    if (tab != i) {
                        tab = i;
                        lastTab = i;
                        scroll = 0;
                        Sfx.click();
                    }
                    return;
                }
            }
            if (sbVisible && mx >= sbX - 4 && mx <= sbX + 8 && my >= sbY && my < sbY + sbH) {
                dragScroll = true;
                scrollFromMouse(my);
                return;
            }
            for (Row row : rows) {
                if (row.visible && row.inside(mx, my)) {
                    if (row.press(fr, 0)) dragRow = row;
                    break;
                }
            }
        }
        if (rightPressed) {
            for (Row row : rows) {
                if (row.visible && row.inside(mx, my)) {
                    row.press(fr, 1);
                    break;
                }
            }
        }
        if (left && dragRow != null) dragRow.drag(fr);
        if (left && dragScroll) scrollFromMouse(my);
        if (leftReleased) {
            if (dragRow != null) dragRow.release();
            dragRow = null;
            dragScroll = false;
        }
    }

    // ================================================================ pages

    private static VisualsConfig.Atmosphere A() {
        return VisualsConfig.get().atmosphere;
    }

    private static VisualsConfig.Crosshair C() {
        return VisualsConfig.get().crosshair;
    }

    private static VisualsConfig.Hit H() {
        return VisualsConfig.get().hit;
    }

    private static VisualsConfig.Kill K() {
        return VisualsConfig.get().kill;
    }

    private static final Function<Float, String> PCT = v -> Math.round(v * 100f) + "%";
    private static final Function<Float, String> DEG = v -> Math.round(v) + "\u00b0";
    private static final Function<Float, String> BLOCKS = v -> Math.round(v) + " blocks";
    private static final Function<Float, String> PX = v -> Math.round(v) + " px";
    private static final Function<Float, String> MS = v -> Math.round(v) + " ms";
    private static final Function<Float, String> INT = v -> Integer.toString(Math.round(v));
    private static final Function<Float, String> X2 = v -> String.format(Locale.ROOT, "%.2fx", v);

    private List<Row> atmosphereRows() {
        List<Row> r = new ArrayList<>();
        r.add(toggle("Atmosphere", () -> A().enabled, v -> A().enabled = v));
        r.add(new Header("Preset"));
        String[] names = Preset.labels();
        for (int i = 0; i < names.length; i += 3) {
            r.add(new ChipRow(names, i, 3, () -> A().preset.ordinal(), v -> A().preset = Preset.values()[v]));
        }
        r.add(new Header("Feel"));
        r.add(fslider("Intensity", 0f, 3f, 0.05f, () -> A().intensity, v -> A().intensity = v, PCT));
        r.add(fslider("Speed", 0.2f, 3f, 0.05f, () -> A().speed, v -> A().speed = v, PCT));
        r.add(fslider("Particle size", 0.3f, 3f, 0.05f, () -> A().size, v -> A().size = v, PCT));
        r.add(fslider("Wind", 0f, 2f, 0.05f, () -> A().wind, v -> A().wind = v, PCT));
        r.add(fslider("Wind direction", 0f, 360f, 5f, () -> A().windDirection, v -> A().windDirection = v, DEG));
        r.add(new Header("Layers"));
        r.add(toggle("Ground layer", () -> A().groundLayer, v -> A().groundLayer = v));
        r.add(fslider("Ground density", 0f, 3f, 0.05f, () -> A().groundDensity, v -> A().groundDensity = v, PCT));
        r.add(islider("Ground height", 1, 10, 1, () -> A().groundHeight, v -> A().groundHeight = v, BLOCKS));
        r.add(toggle("Mid layer", () -> A().midLayer, v -> A().midLayer = v));
        r.add(fslider("Mid density", 0f, 3f, 0.05f, () -> A().midDensity, v -> A().midDensity = v, PCT));
        r.add(toggle("Sky layer", () -> A().skyLayer, v -> A().skyLayer = v));
        r.add(fslider("Sky density", 0f, 3f, 0.05f, () -> A().skyDensity, v -> A().skyDensity = v, PCT));
        r.add(new Header("Area and performance"));
        r.add(islider("Radius", 8, 48, 1, () -> A().radius, v -> A().radius = v, BLOCKS));
        r.add(islider("Max particles", 200, 8000, 100, () -> A().maxParticles, v -> A().maxParticles = v, INT));
        r.add(new Header("Color"));
        r.add(toggle("Custom tint", () -> A().customTint, v -> A().customTint = v));
        r.add(hue("Tint hue", () -> A().tintHue, v -> A().tintHue = v, () -> Gfx.hsv(A().tintHue, A().tintSaturation, 1f)));
        r.add(fslider("Tint strength", 0f, 1f, 0.05f, () -> A().tintSaturation, v -> A().tintSaturation = v, PCT));
        r.add(button("Reset atmosphere", () -> {
            VisualsConfig.get().atmosphere = new VisualsConfig.Atmosphere();
            AtmosphereManager.clear();
        }));
        return r;
    }

    private List<Row> crosshairRows() {
        List<Row> r = new ArrayList<>();
        r.add(toggle("Custom crosshair", () -> C().enabled, v -> C().enabled = v));
        r.add(new PreviewRow());
        r.add(new Header("Shape"));
        for (int i = 0; i < CrosshairRenderer.STYLES.length; i += 3) {
            r.add(new ChipRow(CrosshairRenderer.STYLES, i, 3, () -> C().style, v -> C().style = v));
        }
        r.add(islider("Size", 1, 30, 1, () -> C().size, v -> C().size = v, PX));
        r.add(islider("Thickness", 1, 6, 1, () -> C().thickness, v -> C().thickness = v, PX));
        r.add(islider("Gap", 0, 16, 1, () -> C().gap, v -> C().gap = v, PX));
        r.add(toggle("Outline", () -> C().outline, v -> C().outline = v));
        r.add(new Header("Color"));
        r.add(choice("Color mode", CrosshairRenderer.COLOR_MODES, () -> C().colorMode, v -> C().colorMode = v));
        r.add(hue("Hue", () -> C().hue, v -> C().hue = v, () -> Gfx.hsv(C().hue, C().saturation, 1f)));
        r.add(fslider("Saturation", 0f, 1f, 0.05f, () -> C().saturation, v -> C().saturation = v, PCT));
        r.add(fslider("Opacity", 0.1f, 1f, 0.05f, () -> C().opacity, v -> C().opacity = v, PCT));
        r.add(new Header("Behavior"));
        r.add(toggle("Dynamic spread", () -> C().dynamic, v -> C().dynamic = v));
        r.add(fslider("Spread amount", 0f, 3f, 0.05f, () -> C().dynamicAmount, v -> C().dynamicAmount = v, PCT));
        r.add(toggle("Attack cooldown bar", () -> C().cooldownBar, v -> C().cooldownBar = v));
        r.add(button("Reset crosshair", () -> VisualsConfig.get().crosshair = new VisualsConfig.Crosshair()));
        return r;
    }

    private List<Row> hitRows() {
        List<Row> r = new ArrayList<>();
        r.add(toggle("Hit effects", () -> H().enabled, v -> H().enabled = v));
        r.add(new Header("Hit marker"));
        r.add(toggle("Show marker", () -> H().marker, v -> H().marker = v));
        r.add(choice("Style", Effects.HIT_MARKERS, () -> H().markerStyle, v -> H().markerStyle = v));
        r.add(islider("Size", 2, 16, 1, () -> H().markerSize, v -> H().markerSize = v, PX));
        r.add(islider("Duration", 100, 1500, 50, () -> H().markerDuration, v -> H().markerDuration = v, MS));
        r.add(hue("Hue", () -> H().markerHue, v -> H().markerHue = v, () -> Gfx.hsv(H().markerHue, H().markerSaturation, 1f)));
        r.add(fslider("Saturation", 0f, 1f, 0.05f, () -> H().markerSaturation, v -> H().markerSaturation = v, PCT));
        r.add(toggle("Damage popup", () -> H().damageText, v -> H().damageText = v));
        r.add(new Header("Particles"));
        r.add(toggle("Hit particles", () -> H().particles, v -> H().particles = v));
        r.add(choice("Style", Effects.HIT_PARTICLES, () -> H().particleStyle, v -> H().particleStyle = v));
        r.add(islider("Amount", 1, 60, 1, () -> H().particleCount, v -> H().particleCount = v, INT));
        r.add(fslider("Speed", 0.2f, 3f, 0.05f, () -> H().particleSpeed, v -> H().particleSpeed = v, X2));
        r.add(new Header("Sound"));
        r.add(toggle("Hit sound", () -> H().sound, v -> H().sound = v));
        r.add(choice("Sound", Effects.HIT_SOUNDS, () -> H().soundIndex, v -> H().soundIndex = v));
        r.add(fslider("Volume", 0f, 1f, 0.05f, () -> H().volume, v -> H().volume = v, PCT));
        r.add(fslider("Pitch", 0.5f, 2f, 0.05f, () -> H().pitch, v -> H().pitch = v, X2));
        r.add(button("Reset hit effects", () -> VisualsConfig.get().hit = new VisualsConfig.Hit()));
        return r;
    }

    private List<Row> killRows() {
        List<Row> r = new ArrayList<>();
        r.add(toggle("Kill effects", () -> K().enabled, v -> K().enabled = v));
        r.add(new Header("Kill marker"));
        r.add(toggle("Show marker", () -> K().marker, v -> K().marker = v));
        r.add(islider("Size", 2, 20, 1, () -> K().markerSize, v -> K().markerSize = v, PX));
        r.add(islider("Duration", 200, 2000, 50, () -> K().markerDuration, v -> K().markerDuration = v, MS));
        r.add(hue("Hue", () -> K().markerHue, v -> K().markerHue = v, () -> Gfx.hsv(K().markerHue, K().markerSaturation, 1f)));
        r.add(fslider("Saturation", 0f, 1f, 0.05f, () -> K().markerSaturation, v -> K().markerSaturation = v, PCT));
        r.add(toggle("Kill message", () -> K().message, v -> K().message = v));
        r.add(new Header("Screen flash"));
        r.add(toggle("Flash on kill", () -> K().flash, v -> K().flash = v));
        r.add(fslider("Strength", 0.05f, 1f, 0.05f, () -> K().flashStrength, v -> K().flashStrength = v, PCT));
        r.add(hue("Hue", () -> K().flashHue, v -> K().flashHue = v, () -> Gfx.hsv(K().flashHue, K().flashSaturation, 1f)));
        r.add(fslider("Saturation", 0f, 1f, 0.05f, () -> K().flashSaturation, v -> K().flashSaturation = v, PCT));
        r.add(new Header("Particles"));
        r.add(toggle("Kill particles", () -> K().particles, v -> K().particles = v));
        r.add(choice("Style", Effects.KILL_PARTICLES, () -> K().particleStyle, v -> K().particleStyle = v));
        r.add(islider("Amount", 1, 150, 1, () -> K().particleCount, v -> K().particleCount = v, INT));
        r.add(fslider("Speed", 0.2f, 3f, 0.05f, () -> K().particleSpeed, v -> K().particleSpeed = v, X2));
        r.add(new Header("Sound"));
        r.add(toggle("Kill sound", () -> K().sound, v -> K().sound = v));
        r.add(choice("Sound", Effects.KILL_SOUNDS, () -> K().soundIndex, v -> K().soundIndex = v));
        r.add(fslider("Volume", 0f, 1f, 0.05f, () -> K().volume, v -> K().volume = v, PCT));
        r.add(fslider("Pitch", 0.5f, 2f, 0.05f, () -> K().pitch, v -> K().pitch = v, X2));
        r.add(button("Reset kill effects", () -> VisualsConfig.get().kill = new VisualsConfig.Kill()));
        return r;
    }

    private List<Row> interfaceRows() {
        List<Row> r = new ArrayList<>();
        r.add(new Header("Menu"));
        r.add(new KeyRow("Open key"));
        r.add(hue("Accent color", () -> VisualsConfig.get().uiHue, v -> VisualsConfig.get().uiHue = v,
                () -> Gfx.hsv(VisualsConfig.get().uiHue, 0.55f, 1f)));
        r.add(toggle("Background blur", () -> VisualsConfig.get().uiBlur, v -> VisualsConfig.get().uiBlur = v));
        r.add(new Header("About"));
        r.add(new TextRow("cxnr's-visuals " + CxnrVisuals.VERSION + " for Minecraft 1.21.11"));
        r.add(new TextRow("Settings are saved to config/cxnrs-visuals.json"));
        r.add(button("Reset everything", () -> {
            VisualsConfig c = VisualsConfig.get();
            c.atmosphere = new VisualsConfig.Atmosphere();
            c.crosshair = new VisualsConfig.Crosshair();
            c.hit = new VisualsConfig.Hit();
            c.kill = new VisualsConfig.Kill();
            c.uiHue = 0.56f;
            c.uiBlur = true;
            AtmosphereManager.clear();
        }));
        return r;
    }

    // ---- row factories

    private static Row toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
        return new ToggleRow(label, get, set);
    }

    private static Row fslider(String label, float min, float max, float step, Supplier<Float> get, Consumer<Float> set,
                               Function<Float, String> fmt) {
        return new SliderRow(label, min, max, step, get, set, fmt, false, null);
    }

    private static Row islider(String label, int min, int max, int step, IntSupplier get, IntConsumer set,
                               Function<Float, String> fmt) {
        return new SliderRow(label, min, max, step, () -> (float) get.getAsInt(), v -> set.accept(Math.round(v)), fmt, false, null);
    }

    private static Row hue(String label, Supplier<Float> get, Consumer<Float> set, IntSupplier swatch) {
        return new SliderRow(label, 0f, 1f, 0.01f, get, set, v -> "", true, swatch);
    }

    private static Row choice(String label, String[] options, IntSupplier get, IntConsumer set) {
        return new ChoiceRow(label, options, get, set);
    }

    private static Row button(String label, Runnable action) {
        return new ButtonRow(label, action);
    }

    // ================================================================ rows

    static final class Frame {
        DrawContext g;
        TextRenderer f;
        int mx, my;
        float dt;
        long win;
        VisualsScreen s;
    }

    abstract static class Row {
        int rx, ry, rw;
        boolean visible;

        int height() {
            return 22;
        }

        abstract void draw(Frame fr);

        /** Return true to keep receiving drag() until the mouse is released. */
        boolean press(Frame fr, int button) {
            return false;
        }

        void drag(Frame fr) {
        }

        void release() {
        }

        final boolean inside(int mx, int my) {
            return mx >= rx && mx < rx + rw && my >= ry && my < ry + height();
        }

        final void hover(Frame fr) {
            if (inside(fr.mx, fr.my)) Gfx.rrect(fr.g, rx, ry, rw, height(), 5, 0x12FFFFFF);
        }
    }

    static final class Header extends Row {
        final String text;

        Header(String text) {
            this.text = text;
        }

        @Override
        int height() {
            return 20;
        }

        @Override
        void draw(Frame fr) {
            Gfx.text(fr.g, fr.f, text, rx + 8, ry + 9, Gfx.accent(0xFF));
            int tw = fr.f.getWidth(text);
            fr.g.fill(rx + 14 + tw, ry + 13, rx + rw - 8, ry + 14, 0x22FFFFFF);
        }
    }

    static final class TextRow extends Row {
        final String text;

        TextRow(String text) {
            this.text = text;
        }

        @Override
        int height() {
            return 14;
        }

        @Override
        void draw(Frame fr) {
            Gfx.text(fr.g, fr.f, text, rx + 8, ry + 3, Gfx.TEXT_DIM);
        }
    }

    static final class ToggleRow extends Row {
        final String label;
        final BooleanSupplier get;
        final Consumer<Boolean> set;
        float anim = -1f;

        ToggleRow(String label, BooleanSupplier get, Consumer<Boolean> set) {
            this.label = label;
            this.get = get;
            this.set = set;
        }

        @Override
        void draw(Frame fr) {
            boolean on = get.getAsBoolean();
            if (anim < 0f) anim = on ? 1f : 0f;
            anim += ((on ? 1f : 0f) - anim) * Math.min(1f, fr.dt * 14f);
            hover(fr);
            Gfx.text(fr.g, fr.f, label, rx + 8, ry + 7, Gfx.TEXT);
            int sw = 28, sh = 14;
            int sx = rx + rw - sw - 8, sy = ry + (22 - sh) / 2;
            Gfx.rrect(fr.g, sx, sy, sw, sh, 7, Gfx.lerpColor(0x44FFFFFF, Gfx.accent(0xCC), anim));
            Gfx.rborder(fr.g, sx, sy, sw, sh, 7, 0x44FFFFFF);
            int knob = sh - 4;
            int kx = sx + 2 + Math.round((sw - sh) * anim);
            Gfx.rrect(fr.g, kx, sy + 2, knob, knob, 5, 0xFFFFFFFF);
        }

        @Override
        boolean press(Frame fr, int button) {
            set.accept(!get.getAsBoolean());
            Sfx.click();
            return false;
        }
    }

    static final class SliderRow extends Row {
        final String label;
        final float min, max, step;
        final Supplier<Float> get;
        final Consumer<Float> set;
        final Function<Float, String> fmt;
        final boolean rainbow;
        final IntSupplier swatch;
        int trackX, trackW;

        SliderRow(String label, float min, float max, float step, Supplier<Float> get, Consumer<Float> set,
                  Function<Float, String> fmt, boolean rainbow, IntSupplier swatch) {
            this.label = label;
            this.min = min;
            this.max = max;
            this.step = step;
            this.get = get;
            this.set = set;
            this.fmt = fmt;
            this.rainbow = rainbow;
            this.swatch = swatch;
        }

        @Override
        void draw(Frame fr) {
            float v = get.get();
            float t = Math.max(0f, Math.min(1f, (v - min) / (max - min)));
            hover(fr);
            Gfx.text(fr.g, fr.f, label, rx + 8, ry + 7, Gfx.TEXT);

            int right = rx + rw - 8;
            int valueW = 46;
            if (swatch != null) {
                Gfx.rrect(fr.g, right - 22, ry + 6, 22, 10, 3, 0xFF000000 | swatch.getAsInt());
                Gfx.rborder(fr.g, right - 22, ry + 6, 22, 10, 3, 0x66FFFFFF);
            } else {
                Gfx.textRight(fr.g, fr.f, fmt.apply(v), right, ry + 7, Gfx.TEXT_DIM);
            }
            trackW = Math.max(50, Math.min(110, rw - 190));
            trackX = right - valueW - 6 - trackW;
            int ty = ry + 9;
            if (rainbow) {
                for (int i = 0; i < trackW; i++) {
                    fr.g.fill(trackX + i, ty, trackX + i + 1, ty + 4, 0xFF000000 | Gfx.hsv(i / (float) trackW, 0.8f, 1f));
                }
            } else {
                Gfx.rrect(fr.g, trackX, ty, trackW, 4, 2, 0x33FFFFFF);
                Gfx.rrect(fr.g, trackX, ty, Math.max(4, Math.round(trackW * t)), 4, 2, Gfx.accent(0xE6));
            }
            int kx = trackX + Math.round(trackW * t);
            Gfx.rrect(fr.g, kx - 4, ry + 6, 8, 10, 4, 0xFFFFFFFF);
        }

        @Override
        boolean press(Frame fr, int button) {
            if (fr.mx >= trackX - 6 && fr.mx <= trackX + trackW + 6) {
                apply(fr.mx);
                return true;
            }
            return false;
        }

        @Override
        void drag(Frame fr) {
            apply(fr.mx);
        }

        private void apply(int mx) {
            float t = Math.max(0f, Math.min(1f, (mx - trackX) / (float) trackW));
            float v = min + t * (max - min);
            if (step > 0f) v = Math.round(v / step) * step;
            set.accept(Math.max(min, Math.min(max, v)));
        }
    }

    static final class ChoiceRow extends Row {
        final String label;
        final String[] options;
        final IntSupplier get;
        final IntConsumer set;

        ChoiceRow(String label, String[] options, IntSupplier get, IntConsumer set) {
            this.label = label;
            this.options = options;
            this.get = get;
            this.set = set;
        }

        @Override
        void draw(Frame fr) {
            hover(fr);
            Gfx.text(fr.g, fr.f, label, rx + 8, ry + 7, Gfx.TEXT);
            int pw = 116, ph = 16;
            int x = rx + rw - 8 - pw, y = ry + 3;
            Gfx.rrect(fr.g, x, y, pw, ph, 6, 0x26FFFFFF);
            Gfx.rborder(fr.g, x, y, pw, ph, 6, 0x44FFFFFF);
            Gfx.text(fr.g, fr.f, "<", x + 6, y + 4, Gfx.TEXT_DIM);
            Gfx.text(fr.g, fr.f, ">", x + pw - 12, y + 4, Gfx.TEXT_DIM);
            int i = Math.max(0, Math.min(options.length - 1, get.getAsInt()));
            Gfx.textCentered(fr.g, fr.f, options[i], x + pw / 2, y + 4, 0xFFFFFFFF);
        }

        @Override
        boolean press(Frame fr, int button) {
            int n = options.length;
            int i = get.getAsInt();
            set.accept(button == 1 ? (i + n - 1) % n : (i + 1) % n);
            Sfx.click();
            return false;
        }
    }

    static final class ChipRow extends Row {
        final String[] names;
        final int start, cols;
        final IntSupplier get;
        final IntConsumer set;

        ChipRow(String[] names, int start, int cols, IntSupplier get, IntConsumer set) {
            this.names = names;
            this.start = start;
            this.cols = cols;
            this.get = get;
            this.set = set;
        }

        @Override
        int height() {
            return 24;
        }

        private int chipW() {
            return (rw - 16 - 6 * (cols - 1)) / cols;
        }

        @Override
        void draw(Frame fr) {
            int cw = chipW();
            for (int c = 0; c < cols; c++) {
                int idx = start + c;
                if (idx >= names.length) break;
                int x = rx + 8 + c * (cw + 6), y = ry + 2;
                boolean sel = get.getAsInt() == idx;
                boolean hov = fr.mx >= x && fr.mx < x + cw && fr.my >= y && fr.my < y + 20;
                Gfx.rrect(fr.g, x, y, cw, 20, 6, sel ? Gfx.accent(0x55) : (hov ? 0x26FFFFFF : 0x16FFFFFF));
                Gfx.rborder(fr.g, x, y, cw, 20, 6, sel ? Gfx.accent(0xCC) : 0x30FFFFFF);
                Gfx.textCentered(fr.g, fr.f, names[idx], x + cw / 2, y + 6, sel ? 0xFFFFFFFF : Gfx.TEXT_DIM);
            }
        }

        @Override
        boolean press(Frame fr, int button) {
            int cw = chipW();
            for (int c = 0; c < cols; c++) {
                int idx = start + c;
                if (idx >= names.length) break;
                int x = rx + 8 + c * (cw + 6);
                if (fr.mx >= x && fr.mx < x + cw) {
                    if (get.getAsInt() != idx) {
                        set.accept(idx);
                        Sfx.click();
                    }
                    break;
                }
            }
            return false;
        }
    }

    static final class ButtonRow extends Row {
        final String label;
        final Runnable action;

        ButtonRow(String label, Runnable action) {
            this.label = label;
            this.action = action;
        }

        @Override
        int height() {
            return 24;
        }

        @Override
        void draw(Frame fr) {
            boolean hov = inside(fr.mx, fr.my);
            int x = rx + 8, y = ry + 2, w = rw - 16;
            Gfx.rrect(fr.g, x, y, w, 20, 6, hov ? 0x30FFFFFF : 0x1CFFFFFF);
            Gfx.rborder(fr.g, x, y, w, 20, 6, 0x44FFFFFF);
            Gfx.textCentered(fr.g, fr.f, label, x + w / 2, y + 6, Gfx.TEXT);
        }

        @Override
        boolean press(Frame fr, int button) {
            action.run();
            Sfx.click();
            return false;
        }
    }

    static final class KeyRow extends Row {
        final String label;
        boolean listening;
        final boolean[] held = new boolean[349];

        KeyRow(String label) {
            this.label = label;
        }

        @Override
        void draw(Frame fr) {
            if (listening) {
                for (int k = 32; k <= 348; k++) {
                    boolean down = Keys.isDown(fr.win, k);
                    if (!down) {
                        held[k] = false;
                    } else if (!held[k] && k != 256) {
                        VisualsConfig.get().openKey = k;
                        listening = false;
                        fr.s.keyListening = false;
                        fr.s.prevKey = true;
                        CxnrVisuals.openKeyWasDown = true;
                        Sfx.click();
                        break;
                    }
                }
            }
            hover(fr);
            Gfx.text(fr.g, fr.f, label, rx + 8, ry + 7, Gfx.TEXT);
            int pw = 116, ph = 16;
            int x = rx + rw - 8 - pw, y = ry + 3;
            Gfx.rrect(fr.g, x, y, pw, ph, 6, listening ? Gfx.accent(0x55) : 0x26FFFFFF);
            Gfx.rborder(fr.g, x, y, pw, ph, 6, listening ? Gfx.accent(0xCC) : 0x44FFFFFF);
            String text = listening ? "Press a key..." : Keys.name(VisualsConfig.get().openKey);
            Gfx.textCentered(fr.g, fr.f, text, x + pw / 2, y + 4, 0xFFFFFFFF);
        }

        @Override
        boolean press(Frame fr, int button) {
            listening = !listening;
            fr.s.keyListening = listening;
            if (listening) {
                for (int k = 32; k <= 348; k++) held[k] = Keys.isDown(fr.win, k);
            }
            Sfx.click();
            return false;
        }
    }

    static final class PreviewRow extends Row {
        @Override
        int height() {
            return 62;
        }

        @Override
        void draw(Frame fr) {
            int x = rx + 8, y = ry + 2, w = rw - 16, h = 58;
            Gfx.rrect(fr.g, x, y, w, h, 7, 0x55000000);
            Gfx.rborder(fr.g, x, y, w, h, 7, 0x33FFFFFF);
            Gfx.text(fr.g, fr.f, "Preview", x + 8, y + 6, Gfx.TEXT_OFF);
            VisualsConfig.Crosshair c = C();
            CrosshairRenderer.draw(fr.g, x + w / 2, y + h / 2, c, 0f, CrosshairRenderer.colorFor(c, false), c.opacity);
        }
    }
}
