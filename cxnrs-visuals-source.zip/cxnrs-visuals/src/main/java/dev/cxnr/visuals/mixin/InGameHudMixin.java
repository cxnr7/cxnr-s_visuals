package dev.cxnr.visuals.mixin;

import dev.cxnr.visuals.config.VisualsConfig;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Hides the vanilla crosshair while the custom one is on.
 * require = 0 means: if this method ever gets renamed the mod still loads, you'd just see both crosshairs.
 */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true, require = 0)
    private void cxnrs$hideVanillaCrosshair(CallbackInfo ci) {
        if (VisualsConfig.get().crosshair.enabled) ci.cancel();
    }
}
