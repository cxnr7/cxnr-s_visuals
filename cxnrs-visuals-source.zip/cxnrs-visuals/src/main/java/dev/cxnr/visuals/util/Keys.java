package dev.cxnr.visuals.util;

import org.lwjgl.glfw.GLFW;

import java.util.Locale;

/** Tiny helpers for reading keys straight from GLFW (works the same on every 1.21.x input refactor). */
public final class Keys {
    private Keys() {}

    public static boolean isDown(long window, int key) {
        return key >= GLFW.GLFW_KEY_SPACE && key <= GLFW.GLFW_KEY_LAST
                && GLFW.glfwGetKey(window, key) == GLFW.GLFW_PRESS;
    }

    public static boolean mouseDown(long window, int button) {
        return GLFW.glfwGetMouseButton(window, button) == GLFW.GLFW_PRESS;
    }

    public static String name(int key) {
        switch (key) {
            case 344: return "Right Shift";
            case 340: return "Left Shift";
            case 345: return "Right Ctrl";
            case 341: return "Left Ctrl";
            case 346: return "Right Alt";
            case 342: return "Left Alt";
            case 258: return "Tab";
            case 32: return "Space";
            case 257: return "Enter";
            case 335: return "Num Enter";
            case 260: return "Insert";
            case 261: return "Delete";
            case 268: return "Home";
            case 269: return "End";
            case 266: return "Page Up";
            case 267: return "Page Down";
            case 265: return "Up";
            case 264: return "Down";
            case 263: return "Left";
            case 262: return "Right";
            case 280: return "Caps Lock";
            case 348: return "Menu";
            default: break;
        }
        if (key >= 290 && key <= 314) return "F" + (key - 289);
        if (key >= 320 && key <= 329) return "Num " + (key - 320);
        String n = GLFW.glfwGetKeyName(key, 0);
        if (n != null && !n.isEmpty()) return n.toUpperCase(Locale.ROOT);
        return "Key " + key;
    }
}
