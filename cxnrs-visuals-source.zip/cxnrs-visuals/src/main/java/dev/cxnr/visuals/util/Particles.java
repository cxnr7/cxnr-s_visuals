package dev.cxnr.visuals.util;

import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;

/** Looks vanilla particles up by id. Unknown or parameterised types simply come back as null. */
public final class Particles {
    private static final Map<String, ParticleEffect> CACHE = new HashMap<>();

    private Particles() {}

    public static ParticleEffect lookup(String id) {
        if (CACHE.containsKey(id)) return CACHE.get(id);
        ParticleEffect found = null;
        try {
            Object type = Registries.PARTICLE_TYPE.get(Identifier.of("minecraft", id));
            if (type instanceof ParticleEffect effect) found = effect;
        } catch (RuntimeException ignored) {
            // leave null
        }
        CACHE.put(id, found);
        return found;
    }

    public static ParticleEffect resolve(String id) {
        ParticleEffect e = lookup(id);
        return e != null ? e : ParticleTypes.END_ROD;
    }
}
