package dev.cxnr.visuals.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Plays vanilla sounds by id, so a renamed sound never breaks the build. */
public final class Sfx {
    private Sfx() {}

    public static void play(String id, float volume, float pitch) {
        try {
            SoundEvent event = Registries.SOUND_EVENT.get(Identifier.of("minecraft", id));
            if (event == null) return;
            MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(event, pitch, volume));
        } catch (RuntimeException ignored) {
            // sounds are cosmetic, never crash over them
        }
    }

    public static void click() {
        play("ui.button.click", 0.3f, 1.0f);
    }
}
